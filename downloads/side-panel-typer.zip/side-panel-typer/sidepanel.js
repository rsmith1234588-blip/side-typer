'use strict';

/* ------------------------------------------------------------------ *
 * Side Panel Typer
 * ------------------------------------------------------------------ */

const $ = (id) => document.getElementById(id);

const els = {
  text: $('text'),
  counts: $('counts'),
  target: $('target'),
  speed: $('speed'),
  speedOut: $('speedOut'),
  randomize: $('randomize'),
  variation: $('variation'),
  variationOut: $('variationOut'),
  stripIndent: $('stripIndent'),
  start: $('start'),
  pause: $('pause'),
  stop: $('stop'),
  clear: $('clear'),
  bar: $('bar'),
  fill: $('fill'),
  progressText: $('progressText'),
  eta: $('eta'),
  status: $('status'),
};

const STORE_KEY = 'side-panel-typer:v1';
const CDP_VERSION = '1.3';
const MOD_SHIFT = 8;

/* -------------------------- settings ------------------------------- */

// Set to false to disable fake typos and their later corrections.
const ENABLE_TYPO_CORRECTION = false;

const SAVE_PAUSE_EVERY = 500;
const SAVE_PAUSE_MS = 5000;

// Fake typo settings
const TYPO_MIN_TYPED = 200;
const TYPO_CHANCE = 0.008;

const TYPO_WAIT_MIN = 1200;
const TYPO_WAIT_MAX = 3500;

const TYPO_MIN_LENGTH = 3;
const TYPO_MAX_LENGTH = 8;

const TYPO_COOLDOWN_MIN = 5000;
const TYPO_COOLDOWN_MAX = 12000;

let nextTypoAllowedAt = 0;
let saveBlock = 0;

/* ---------------------------- key table ---------------------------- */

const KEYS = new Map();

(function buildKeyTable() {
  for (let i = 0; i < 26; i++) {
    const lower = String.fromCharCode(97 + i);
    const upper = lower.toUpperCase();
    const code = 'Key' + upper;
    const vk = upper.charCodeAt(0);

    KEYS.set(lower, {
      key: lower,
      code,
      vk,
      shift: false,
      base: lower,
    });

    KEYS.set(upper, {
      key: upper,
      code,
      vk,
      shift: true,
      base: lower,
    });
  }

  for (let d = 0; d <= 9; d++) {
    const ch = String(d);

    KEYS.set(ch, {
      key: ch,
      code: 'Digit' + ch,
      vk: 48 + d,
      shift: false,
      base: ch,
    });
  }

  const shiftedDigits = ')!@#$%^&*(';

  for (let d = 0; d <= 9; d++) {
    const ch = shiftedDigits[d];

    KEYS.set(ch, {
      key: ch,
      code: 'Digit' + d,
      vk: 48 + d,
      shift: true,
      base: String(d),
    });
  }

  [
    ['-', '_', 'Minus', 189],
    ['=', '+', 'Equal', 187],
    ['[', '{', 'BracketLeft', 219],
    [']', '}', 'BracketRight', 221],
    ['\\', '|', 'Backslash', 220],
    [';', ':', 'Semicolon', 186],
    ["'", '"', 'Quote', 222],
    [',', '<', 'Comma', 188],
    ['.', '>', 'Period', 190],
    ['/', '?', 'Slash', 191],
    ['`', '~', 'Backquote', 192],
  ].forEach(([base, shifted, code, vk]) => {
    KEYS.set(base, {
      key: base,
      code,
      vk,
      shift: false,
      base,
    });

    KEYS.set(shifted, {
      key: shifted,
      code,
      vk,
      shift: true,
      base,
    });
  });

  KEYS.set(' ', {
    key: ' ',
    code: 'Space',
    vk: 32,
    shift: false,
    base: ' ',
  });
})();

/* ------------------------------ state ------------------------------ */

let state = 'idle';
let runId = 0;
let tabId = null;
let chars = [];
let index = 0;
let wakeSleep = null;
let resumeResolver = null;

const pendingCorrections = [];

/* ---------------------------- persistence --------------------------- */

function loadSaved() {
  try {
    const saved = JSON.parse(
      localStorage.getItem(STORE_KEY) || '{}'
    );

    if (typeof saved.text === 'string') {
      els.text.value = saved.text;
    }

    if (saved.speed) {
      els.speed.value = saved.speed;
    }

    if (typeof saved.randomize === 'boolean') {
      els.randomize.checked = saved.randomize;
    }

    if (saved.variation !== undefined) {
      els.variation.value = saved.variation;
    }

    if (typeof saved.stripIndent === 'boolean') {
      els.stripIndent.checked = saved.stripIndent;
    }
  } catch {
    /* Ignore corrupt storage. */
  }
}

let saveTimer = null;

function saveSoon() {
  clearTimeout(saveTimer);

  saveTimer = setTimeout(() => {
    try {
      localStorage.setItem(
        STORE_KEY,
        JSON.stringify({
          text: els.text.value,
          speed: els.speed.value,
          randomize: els.randomize.checked,
          variation: els.variation.value,
          stripIndent: els.stripIndent.checked,
        })
      );
    } catch {
      /* Ignore storage errors. */
    }
  }, 300);
}

/* ------------------------------ helpers ----------------------------- */

const fmt = (n) => n.toLocaleString();

const wpm = () => Number(els.speed.value);

const baseDelayMs = () => 60000 / (wpm() * 5);

function nextDelayMs() {
  const base = baseDelayMs();

  if (!els.randomize.checked) {
    return base;
  }

  const spread = Number(els.variation.value) / 100;

  return Math.max(
    0,
    base * (1 + (Math.random() * 2 - 1) * spread)
  );
}

function randomInt(min, max) {
  return Math.floor(
    Math.random() * (max - min + 1)
  ) + min;
}

function sleep(ms) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      wakeSleep = null;
      resolve();
    }, ms);

    wakeSleep = () => {
      clearTimeout(timer);
      wakeSleep = null;
      resolve();
    };
  });
}

function formatDuration(seconds) {
  seconds = Math.max(0, Math.round(seconds));

  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;

  if (h) {
    return `${h}h ${String(m).padStart(2, '0')}m`;
  }

  if (m) {
    return `${m}m ${String(s).padStart(2, '0')}s`;
  }

  return `${s}s`;
}

function setStatus(message, kind = '') {
  els.status.textContent = message;
  els.status.className = 'status' + (kind ? ' ' + kind : '');
}

/* ------------------------------- UI --------------------------------- */

function renderCounts() {
  const t = els.text.value;
  const c = Array.from(t).length;
  const w = t.trim() ? t.trim().split(/\s+/).length : 0;
  const l = t ? t.split(/\r\n|\r|\n/).length : 0;

  els.counts.textContent =
    `${fmt(c)} characters · ${fmt(w)} words · ${fmt(l)} lines`;
}

function renderSettings() {
  const ms = baseDelayMs();

  els.speedOut.textContent =
    `${wpm()} WPM · ${ms >= 10 ? Math.round(ms) : ms.toFixed(1)} ms per character`;

  els.variation.disabled = !els.randomize.checked;

  els.variationOut.textContent = els.randomize.checked
    ? `±${els.variation.value}%`
    : 'off';
}

function renderProgress() {
  const total = chars.length;
  const pct = total ? (index / total) * 100 : 0;

  els.fill.style.width = pct + '%';

  els.bar.setAttribute(
    'aria-valuenow',
    String(Math.round(pct))
  );

  els.progressText.textContent =
    `${fmt(index)} / ${fmt(total)} characters (${pct.toFixed(pct < 10 ? 1 : 0)}%)`;

  els.eta.textContent =
    state !== 'idle' && total > index
      ? `${formatDuration(((total - index) * baseDelayMs()) / 1000)} left`
      : '';
}

function renderButtons() {
  const active = state !== 'idle';

  els.start.disabled = active || !els.text.value.length;
  els.pause.disabled = !active;

  els.pause.textContent =
    state === 'paused' ? 'Resume' : 'Pause';

  els.stop.disabled = !active;
  els.clear.disabled = active;
  els.text.readOnly = active;
}

async function renderTarget() {
  try {
    let id = tabId;

    if (id === null) {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      id = tab ? tab.id : null;
    }

    if (id === null) {
      els.target.textContent = 'No active tab';
      return;
    }

    const targets = await chrome.debugger.getTargets();
    const t = targets.find((x) => x.tabId === id);

    els.target.textContent =
      t && t.title ? t.title : 'Active tab';

    els.target.title = t && t.url ? t.url : '';
  } catch {
    els.target.textContent = 'Active tab';
  }
}

function render() {
  renderCounts();
  renderSettings();
  renderProgress();
  renderButtons();
}

/* --------------------------- debugger plumbing ----------------------- */

const send = (method, params) =>
  chrome.debugger.sendCommand({ tabId }, method, params);

async function attach(id) {
  await chrome.debugger.attach(
    { tabId: id },
    CDP_VERSION
  );

  tabId = id;

  await enableFocusEmulation();
}

async function enableFocusEmulation() {
  try {
    await send(
      'Emulation.setFocusEmulationEnabled',
      { enabled: true }
    );
  } catch {
    /* Optional. */
  }
}

async function detach() {
  const id = tabId;

  if (id === null) {
    return;
  }

  try {
    await chrome.debugger.sendCommand(
      { tabId: id },
      'Emulation.setFocusEmulationEnabled',
      { enabled: false }
    );
  } catch {
    /* Ignore. */
  }

  try {
    await chrome.debugger.detach({ tabId: id });
  } catch {
    /* Already detached. */
  }

  if (tabId === id) {
    tabId = null;
  }
}

/* ------------------------------ typing ------------------------------- */

async function pressKey(info, modifiers = 0, text = '') {
  await send('Input.dispatchKeyEvent', {
    type: 'keyDown',
    modifiers,
    key: info.key,
    code: info.code,
    text,
    unmodifiedText: info.base !== undefined
      ? info.base
      : text,
    windowsVirtualKeyCode: info.vk,
    nativeVirtualKeyCode: info.vk,
  });

  await send('Input.dispatchKeyEvent', {
    type: 'keyUp',
    modifiers,
    key: info.key,
    code: info.code,
    windowsVirtualKeyCode: info.vk,
    nativeVirtualKeyCode: info.vk,
  });
}

async function typeChar(ch) {
  if (ch === '\n') {
    return pressKey(
      {
        key: 'Enter',
        code: 'Enter',
        vk: 13,
        base: '\r',
      },
      0,
      '\r'
    );
  }

  if (ch === '\t') {
    return pressKey(
      {
        key: 'Tab',
        code: 'Tab',
        vk: 9,
        base: '\t',
      },
      0,
      '\t'
    );
  }

  const info = KEYS.get(ch);

  if (info) {
    return pressKey(
      info,
      info.shift ? MOD_SHIFT : 0,
      ch
    );
  }

  return send('Input.insertText', { text: ch });
}

function prepareText() {
  let t = els.text.value.replace(/\r\n?/g, '\n');

  if (els.stripIndent.checked) {
    t = t.replace(/\n[ \t]+/g, '\n');
  }

  return Array.from(t);
}

/* --------------------------- special keys --------------------------- */

async function specialKey(key, code, vk, modifiers = 0) {
  await send('Input.dispatchKeyEvent', {
    type: 'keyDown',
    modifiers,
    key,
    code,
    windowsVirtualKeyCode: vk,
    nativeVirtualKeyCode: vk,
  });

  await send('Input.dispatchKeyEvent', {
    type: 'keyUp',
    modifiers,
    key,
    code,
    windowsVirtualKeyCode: vk,
    nativeVirtualKeyCode: vk,
  });
}

async function moveCursorLeft(count) {
  for (let i = 0; i < count; i++) {
    await specialKey('ArrowLeft', 'ArrowLeft', 37);
  }
}

async function moveCursorRight(count) {
  for (let i = 0; i < count; i++) {
    await specialKey('ArrowRight', 'ArrowRight', 39);
  }
}

// Shift + ArrowLeft selects characters to the left of the cursor.
async function selectLeft(count) {
  for (let i = 0; i < count; i++) {
    await specialKey(
      'ArrowLeft',
      'ArrowLeft',
      37,
      MOD_SHIFT
    );
  }
}

/* --------------------------- typo generation ------------------------ */

// Swap two adjacent letters: "jumps" -> "jupms"
function makeTypo(word) {
  const letters = Array.from(word);

  for (let attempt = 0; attempt < 10; attempt++) {
    const pos = randomInt(0, letters.length - 2);
    const copy = [...letters];

    [copy[pos], copy[pos + 1]] =
      [copy[pos + 1], copy[pos]];

    const result = copy.join('');

    if (result !== word) {
      return result;
    }
  }

  return null;
}

function findUpcomingTypo() {
  if (index < TYPO_MIN_TYPED || index >= chars.length) {
    return null;
  }

  // Find the next word.
  let start = index;

  while (start < chars.length && /\s/.test(chars[start])) {
    start++;
  }

  if (start >= chars.length) {
    return null;
  }

  let end = start;

  while (end < chars.length && !/\s/.test(chars[end])) {
    end++;
  }

  const word = chars.slice(start, end).join('');

  // Only the leading letters, so punctuation never gets swapped in.
  const m = word.match(/^\p{L}+/u);

  if (!m) {
    return null;
  }

  const core = m[0];
  const len = Array.from(core).length;

  if (len < TYPO_MIN_LENGTH || len > TYPO_MAX_LENGTH) {
    return null;
  }

  const wrong = makeTypo(core);

  if (!wrong) {
    return null;
  }

  return {
    offset: start - index,
    right: core,
    wrong,
  };
}

/* -------------------------- typo correction ------------------------- */

async function correctTypo(correction, myRun) {
  if (myRun !== runId) {
    return;
  }

  const { position, wrong, right } = correction;
  const wrongLen = Array.from(wrong).length;

  // Characters typed AFTER the typo word.
  const back = index - (position + wrongLen);

  if (back < 0) {
    return;
  }

  await moveCursorLeft(back);

  if (myRun !== runId) {
    return;
  }

  // Select the wrong word.
  await selectLeft(wrongLen);

  if (myRun !== runId) {
    return;
  }

  // Delete the selection.
  await specialKey('Backspace', 'Backspace', 8);

  if (myRun !== runId) {
    return;
  }

  // Type the correct word.
  for (const ch of Array.from(right)) {
    await typeChar(ch);

    if (myRun !== runId) {
      return;
    }
  }

  // Return to the end of the document.
  await moveCursorRight(back);
}

/* ------------------------- correction queue ------------------------- */

async function processCorrections(myRun) {
  if (!pendingCorrections.length) {
    return;
  }

  const now = Date.now();

  for (let i = 0; i < pendingCorrections.length; i++) {
    const correction = pendingCorrections[i];

    // Let the typer get a bit further before noticing the mistake.
    if (
      now >= correction.correctAt &&
      correction.position < index - 10
    ) {
      pendingCorrections.splice(i, 1);

      setStatus('Correcting a small typo…');

      await correctTypo(correction, myRun);

      setStatus('Typing…');

      return;
    }
  }
}

/* ------------------------------ run loop ----------------------------- */

async function run(myRun) {
  while (true) {
    if (myRun !== runId) {
      return;
    }

    if (state === 'paused') {
      await new Promise((resolve) => {
        resumeResolver = resolve;
      });

      continue;
    }

    if (index >= chars.length) {
      break;
    }

    let typoForThisWord = null;
    const now = Date.now();

    // The constant controls whether fake typos can happen at all.
    if (
      ENABLE_TYPO_CORRECTION &&
      index >= TYPO_MIN_TYPED &&
      now >= nextTypoAllowedAt &&
      Math.random() < TYPO_CHANCE
    ) {
      typoForThisWord = findUpcomingTypo();

      if (typoForThisWord) {
        nextTypoAllowedAt =
          now + randomInt(
            TYPO_COOLDOWN_MIN,
            TYPO_COOLDOWN_MAX
          );
      }
    }

    try {
      if (typoForThisWord) {
        const { offset, right, wrong } = typoForThisWord;

        // Type the text before the word normally.
        for (let i = 0; i < offset; i++) {
          await typeChar(chars[index]);

          index++;
          renderProgress();

          await sleep(nextDelayMs());

          if (myRun !== runId) {
            return;
          }
        }

        // Remember where the wrong word begins.
        const typoPosition = index;

        // Type the WRONG word.
        for (const ch of Array.from(wrong)) {
          await typeChar(ch);

          index++;
          renderProgress();

          await sleep(nextDelayMs());

          if (myRun !== runId) {
            return;
          }
        }

        // Fix it later, not immediately.
        pendingCorrections.push({
          position: typoPosition,
          wrong,
          right,
          correctAt:
            Date.now() + randomInt(
              TYPO_WAIT_MIN,
              TYPO_WAIT_MAX
            ),
        });
      } else {
        await typeChar(chars[index]);

        index++;
        renderProgress();
      }
    } catch (err) {
      if (myRun !== runId) {
        return;
      }

      return finish(
        `Typing failed: ${err.message || err}`,
        'error'
      );
    }

    if (myRun !== runId) {
      return;
    }

    // Process corrections only when the feature is enabled.
    if (ENABLE_TYPO_CORRECTION) {
      await processCorrections(myRun);

      if (myRun !== runId) {
        return;
      }
    }

    // Every 100 characters, stop for five seconds.
    const block = Math.floor(index / SAVE_PAUSE_EVERY);

    if (block > saveBlock) {
      saveBlock = block;

      setStatus(`Saving… ${fmt(index)} characters typed.`);

      await sleep(SAVE_PAUSE_MS);

      if (myRun !== runId) {
        return;
      }

      setStatus('Typing…');
    }

    await sleep(nextDelayMs());
  }

  // Correct remaining typos before finishing, if enabled.
  if (ENABLE_TYPO_CORRECTION) {
    while (pendingCorrections.length) {
      if (myRun !== runId) {
        return;
      }

      const correction = pendingCorrections.shift();

      await correctTypo(correction, myRun);
    }
  } else {
    pendingCorrections.length = 0;
  }

  if (myRun === runId) {
    finish(
      `Done. Typed ${fmt(chars.length)} characters.`,
      'done'
    );
  }
}

/* ------------------------------ controls ----------------------------- */

async function finish(message, kind = '') {
  runId++;
  state = 'idle';

  if (wakeSleep) {
    wakeSleep();
  }

  if (resumeResolver) {
    resumeResolver();
    resumeResolver = null;
  }

  render();
  setStatus(message, kind);

  await detach();
  renderTarget();
}

async function start() {
  if (state !== 'idle') {
    return;
  }

  chars = prepareText();
  index = 0;
  saveBlock = 0;
  pendingCorrections.length = 0;

  // No typo right at the beginning.
  nextTypoAllowedAt = Date.now() + 10000;

  if (!chars.length) {
    return;
  }

  els.start.disabled = true;
  setStatus('Connecting to the active tab…');

  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  });

  if (!tab) {
    render();
    return setStatus('No active tab found.', 'error');
  }

  try {
    await attach(tab.id);
  } catch (err) {
    tabId = null;
    render();

    return setStatus(
      `Can't type into this tab: ${err.message}`,
      'error'
    );
  }

  state = 'running';

  render();
  renderTarget();
  setStatus('Typing…');

  run(++runId);
}

function togglePause() {
  if (state === 'running') {
    state = 'paused';

    if (wakeSleep) {
      wakeSleep();
    }

    render();
    setStatus('Paused. Position is kept.');
  } else if (state === 'paused') {
    resume();
  }
}

async function resume() {
  try {
    const tab = await chrome.tabs.get(tabId);

    if (!tab.active) {
      await chrome.tabs.update(tabId, { active: true });
    }

    await enableFocusEmulation();
  } catch {
    return finish(
      'The target tab is no longer available.',
      'error'
    );
  }

  state = 'running';

  render();
  setStatus('Typing…');

  if (resumeResolver) {
    resumeResolver();
    resumeResolver = null;
  }
}

function stop() {
  if (state === 'idle') {
    return;
  }

  pendingCorrections.length = 0;

  finish(`Stopped at ${fmt(index)} of ${fmt(chars.length)} characters.`);
}

function clearAll() {
  if (state !== 'idle') {
    return;
  }

  els.text.value = '';
  chars = [];
  index = 0;
  pendingCorrections.length = 0;

  render();
  saveSoon();

  setStatus(
    'Ready. Click into the field you want to type in, then press Start.'
  );

  els.text.focus();
}

/* ------------------------------ events ------------------------------- */

els.text.addEventListener('input', () => {
  renderCounts();
  renderButtons();
  saveSoon();
});

['speed', 'variation', 'randomize', 'stripIndent'].forEach((id) =>
  els[id].addEventListener('input', () => {
    renderSettings();
    renderProgress();
    saveSoon();
  })
);

els.start.addEventListener('click', start);
els.pause.addEventListener('click', togglePause);
els.stop.addEventListener('click', stop);
els.clear.addEventListener('click', clearAll);

/* --------------------------- tab events ----------------------------- */

chrome.debugger.onDetach.addListener((source, reason) => {
  if (state === 'idle' || source.tabId !== tabId) {
    return;
  }

  runId++;
  state = 'idle';
  tabId = null;
  pendingCorrections.length = 0;

  if (wakeSleep) {
    wakeSleep();
  }

  if (resumeResolver) {
    resumeResolver();
    resumeResolver = null;
  }

  render();

  const why =
    reason === 'canceled_by_user'
      ? 'the debugging banner was dismissed'
      : reason.replace(/_/g, ' ');

  setStatus(
    `Stopped at ${fmt(index)} of ${fmt(chars.length)} characters: ${why}.`,
    'error'
  );

  renderTarget();
});

chrome.tabs.onActivated.addListener(({ tabId: activated }) => {
  if (state === 'running' && activated !== tabId) {
    state = 'paused';

    if (wakeSleep) {
      wakeSleep();
    }

    render();

    setStatus(
      'Paused because you left the target tab. Press Resume to return and continue.'
    );
  }

  renderTarget();
});

chrome.tabs.onUpdated.addListener((id, change) => {
  if (
    id === tabId &&
    state === 'running' &&
    change.status === 'loading'
  ) {
    state = 'paused';

    if (wakeSleep) {
      wakeSleep();
    }

    render();

    setStatus(
      'Paused because the page is navigating. Press Resume when it has loaded.'
    );
  }

  if (tabId === null && change.title !== undefined) {
    renderTarget();
  }
});

chrome.tabs.onRemoved.addListener((id) => {
  if (id === tabId && state !== 'idle') {
    finish('The target tab was closed.', 'error');
  }
});

/* ------------------------------- init -------------------------------- */

loadSaved();
render();
renderTarget();