// The service worker only wires the toolbar icon to the Side Panel.
// All typing logic lives in sidepanel.js so it stays alive for as long as the panel is open
// (MV3 service workers can be suspended mid-run).
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((err) => console.error('setPanelBehavior failed:', err));
